RiffStream - Real Guitar Stream Alerts (Vol. 1, Expanded)
==========================================================
66 real electric-guitar alert sounds across 10 tones. Every take played,
picked and mixed by hand through boutique pedals - no synth presets, no
stock-audio farm. MP3, normalized to a consistent loudness. Works with
Streamlabs, StreamElements and OBS.

WHAT'S INSIDE (10 tones)
  01 Clean            - new followers / subs
  02 Overdrive        - donations / bits
  03 Fuzz             - raids / hype trains
  04 Crunch           - alerts with attitude
  05 Blues            - warm, expressive stingers
  06 Rock             - punchy hits
  07 Funk             - tight, rhythmic accents
  08 Delay            - spacious, echoing cues
  09 Reverb           - big, ambient swells
  10 Ambient / Chords - mysterious intros / scene changes

HOW TO USE
  Pick a sound per stream event in Streamlabs/StreamElements/OBS and set it
  as the alert audio. Mix them however you like.

Full details & updates: riffstream.itch.io
